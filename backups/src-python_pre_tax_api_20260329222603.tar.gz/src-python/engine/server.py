import json
import traceback

class JSONRPCServer:
    def __init__(self):
        self.methods = {}

    def register_method(self, name: str, func: callable):
        self.methods[name] = func

    def _make_error(self, code: int, message: str, req_id=None):
        return {
            "jsonrpc": "2.0",
            "error": {"code": code, "message": message},
            "id": req_id
        }

    def _make_success(self, result, req_id):
        return {
            "jsonrpc": "2.0",
            "result": result,
            "id": req_id
        }

    def handle_request(self, req_str: str) -> str:
        try:
            req = json.loads(req_str)
        except json.JSONDecodeError:
            return json.dumps(self._make_error(-32700, "Parse error"))
            
        req_id = req.get("id")

        if not isinstance(req, dict) or req.get("jsonrpc") != "2.0" or "method" not in req:
            return json.dumps(self._make_error(-32600, "Invalid Request", req_id))

        method_name = req["method"]
        if method_name not in self.methods:
            return json.dumps(self._make_error(-32601, f"Method not found: {method_name}", req_id))

        params = req.get("params", {})
        func = self.methods[method_name]

        try:
            if isinstance(params, dict):
                result = func(**params)
            elif isinstance(params, list):
                result = func(*params)
            else:
                result = func()
            return json.dumps(self._make_success(result, req_id))
        except Exception as e:
            # -32000 to -32099 are reserved for implementation-defined server-errors
            # tb = traceback.format_exc() # Useful for debugging but maybe not expose everything to client
            return json.dumps(self._make_error(-32000, str(e), req_id))

    def run_stdio(self): # pragma: no cover
        """
        Main loop for standard I/O communication (used by Tauri sidecar).
        """
        import sys
        for line in sys.stdin:
            line = line.strip()
            if not line:
                continue
            response = self.handle_request(line)
            sys.stdout.write(response + "\n")
            sys.stdout.flush()
