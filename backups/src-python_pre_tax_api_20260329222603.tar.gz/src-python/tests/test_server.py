import json
import pytest
from engine.server import JSONRPCServer

def test_handle_valid_request():
    server = JSONRPCServer()
    # Mock a simple ping method
    server.register_method("ping", lambda: "pong")
    
    req_str = json.dumps({"jsonrpc": "2.0", "method": "ping", "id": 1})
    res_str = server.handle_request(req_str)
    res = json.loads(res_str)
    
    assert res["jsonrpc"] == "2.0"
    assert res["id"] == 1
    assert res["result"] == "pong"
    assert "error" not in res

def test_handle_invalid_json():
    server = JSONRPCServer()
    req_str = "{invalid_json: true"
    res_str = server.handle_request(req_str)
    res = json.loads(res_str)
    
    assert res["jsonrpc"] == "2.0"
    assert res["error"]["code"] == -32700
    assert "Parse error" in res["error"]["message"]

def test_handle_method_not_found():
    server = JSONRPCServer()
    req_str = json.dumps({"jsonrpc": "2.0", "method": "unknown_method", "id": 2})
    res_str = server.handle_request(req_str)
    res = json.loads(res_str)
    
    assert res["jsonrpc"] == "2.0"
    assert res["id"] == 2
    assert res["error"]["code"] == -32601
    assert "Method not found" in res["error"]["message"]

def test_handle_method_with_params():
    server = JSONRPCServer()
    server.register_method("add", lambda a, b: a + b)
    
    req_str = json.dumps({"jsonrpc": "2.0", "method": "add", "params": {"a": 2, "b": 3}, "id": 3})
    res_str = server.handle_request(req_str)
    res = json.loads(res_str)
    
    assert res["result"] == 5

def test_handle_method_exception():
    server = JSONRPCServer()
    def raise_err():
        raise ValueError("test error")
    server.register_method("fail", raise_err)
    
    req_str = json.dumps({"jsonrpc": "2.0", "method": "fail", "id": 4})
    res_str = server.handle_request(req_str)
    res = json.loads(res_str)
    
    assert res["error"]["code"] == -32000 # generic server error
    assert "test error" in res["error"]["message"]
