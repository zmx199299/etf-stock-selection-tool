import sys
import logging
from engine.server import JSONRPCServer

# Basic logging to stderr so it doesn't mess up JSON-RPC on stdout
logging.basicConfig(level=logging.INFO, stream=sys.stderr, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def ping():
    return "pong"

def get_engine_status():
    return {"status": "running", "version": "1.0.0"}

def main():
    logger.info("Starting Python ETF Engine...")
    server = JSONRPCServer()
    
    # Register core methods
    server.register_method("ping", ping)
    server.register_method("get_engine_status", get_engine_status)
    
    # Block and run on stdio
    logger.info("Engine listening on stdin...")
    server.run_stdio()

if __name__ == "__main__":
    main()
