import pytest
from engine.scoring.calculator import CostCalculator

def test_etf_buy_cost_normal():
    # 测试普通的买入佣金计算（无免5）
    calculator = CostCalculator(commission_rate=0.0001, min_commission=5.0, stamp_duty=0.0)
    # 交易金额 10000，佣金 10000 * 0.0001 = 1，不足5元按5元收
    cost = calculator.calculate_buy_cost(10000.0)
    assert cost == 5.0
    
    # 交易金额 100000，佣金 100000 * 0.0001 = 10，大于5元按10元收
    cost2 = calculator.calculate_buy_cost(100000.0)
    assert cost2 == 10.0

def test_etf_buy_cost_free_5():
    # 测试免5的情况
    calculator = CostCalculator(commission_rate=0.0001, min_commission=0.0, stamp_duty=0.0)
    # 交易金额 10000，佣金 1
    cost = calculator.calculate_buy_cost(10000.0)
    assert cost == 1.0

def test_sell_cost_with_stamp_duty():
    # 测试卖出时带印花税的情况（如某些LOF或股票）
    calculator = CostCalculator(commission_rate=0.0001, min_commission=5.0, stamp_duty=0.001)
    # 卖出金额 10000，佣金5元，印花税 10000 * 0.001 = 10，总成本 15
    cost = calculator.calculate_sell_cost(10000.0)
    assert cost == 15.0

def test_profit_calculation():
    # 测试净利润计算
    calculator = CostCalculator(commission_rate=0.0001, min_commission=5.0, stamp_duty=0.0)
    # 买入 10000，佣金 5
    # 卖出 11000，佣金 5
    # 毛利 1000，净利 1000 - 10 = 990
    profit = calculator.calculate_net_profit(10000.0, 11000.0)
    assert profit == 990.0
