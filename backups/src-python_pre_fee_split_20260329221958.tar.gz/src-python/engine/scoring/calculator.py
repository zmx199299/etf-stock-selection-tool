class CostCalculator:
    def __init__(self, commission_rate=0.0001, min_commission=5.0, stamp_duty=0.0):
        self.commission_rate = commission_rate
        self.min_commission = min_commission
        self.stamp_duty = stamp_duty

    def calculate_buy_cost(self, amount: float) -> float:
        """计算买入成本（不含印花税）"""
        commission = amount * self.commission_rate
        if self.min_commission > 0:
            commission = max(commission, self.min_commission)
        return commission

    def calculate_sell_cost(self, amount: float) -> float:
        """计算卖出成本（可能包含印花税）"""
        commission = amount * self.commission_rate
        if self.min_commission > 0:
            commission = max(commission, self.min_commission)
            
        stamp_tax = amount * self.stamp_duty
        return commission + stamp_tax

    def calculate_net_profit(self, buy_amount: float, sell_amount: float) -> float:
        """计算净利润：毛利润减去买入、卖出总成本"""
        gross_profit = sell_amount - buy_amount
        buy_cost = self.calculate_buy_cost(buy_amount)
        sell_cost = self.calculate_sell_cost(sell_amount)
        
        return gross_profit - buy_cost - sell_cost
